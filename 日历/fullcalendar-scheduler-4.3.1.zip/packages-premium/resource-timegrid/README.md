
# FullCalendar Resource Time Grid Plugin

Displays events on a vertical resource view with time slots

[View the docs &raquo;](https://fullcalendar.io/docs/vertical-resource-view)

This package was created from the [FullCalendar monorepo &raquo;](https://github.com/fullcalendar/fullcalendar-scheduler)
