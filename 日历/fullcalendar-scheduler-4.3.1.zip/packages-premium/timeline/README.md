
# FullCalendar Timeline Plugin

Display events on a horizontal time axis (without resources)

[View the docs &raquo;](https://fullcalendar.io/docs/timeline-view-no-resources)

This package was created from the [FullCalendar monorepo &raquo;](https://github.com/fullcalendar/fullcalendar-scheduler)
